import java.util.Scanner;
public class Banco {

}
